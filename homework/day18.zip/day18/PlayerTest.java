package com.day18;

public class PlayerTest {

	public static void main(String[] args) {
		CDPlayer cd = new CDPlayer();
		cd.play();
		cd.paused();
		cd.play(100);
		cd.stop();
		
		cd.nextTrack();
		cd.nextTrack();
		cd.prevTrack();
		
	}

}
