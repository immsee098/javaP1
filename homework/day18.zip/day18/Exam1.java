package com.day18;

import java.util.Scanner;  

interface IShape {
	public abstract double findArea();
}

class Circle implements IShape {
	final double PI = 3.14;
	private int r;

	public Circle(int r){
		this.r = r;
	}

	public double findArea() {
		return PI*r*r;
	}
}

class Rectangle implements IShape {
	private int w;
	private int h;

	public Rectangle(int w, int h){
		this.w =w;
		this.h = h;
	}

	public double findArea() {
		return w*h;
	}
}

class Exam1{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("������ �����ϼ���(1. ��, 2. �簢��)");
		int s = sc.nextInt();
		
		IShape sh = null;
		if (s == 1)	{
			System.out.println("������ �Է�!");
			int r = sc.nextInt();
			sh =  new Circle(r);
		}else if (s == 2){
			System.out.println("����, ���� �Է�!");
			int w = sc.nextInt();
			int h = sc.nextInt();
			sh = new Rectangle(w, h);
		}else {
			System.out.println("�߸� �Է�!");
			return;
		}
		
		double area = sh.findArea();
		System.out.println("���� : "+area);
		
		System.out.println("\n======�޼��� �̿�======");
		IShape iSh=createShape(s);
		System.out.println("����: "+iSh.findArea());
		
	}//main
	
	public static IShape createShape(int type) {
		Scanner sc = new Scanner(System.in);
		IShape sh = null;
		
		if (type == 1)	{
			System.out.println("������ �Է�!");
			int r = sc.nextInt();
			sh =  new Circle(r);
		}else if (type == 2){
			System.out.println("����, ���� �Է�!");
			int w = sc.nextInt();
			int h = sc.nextInt();
			sh = new Rectangle(w, h);
		}
		
		return sh;
	}
	
}//class